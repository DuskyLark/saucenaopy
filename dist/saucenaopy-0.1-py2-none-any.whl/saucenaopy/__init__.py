from saucenao.py import SauceNAO
